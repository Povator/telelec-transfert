package editor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class CentralServer {

    private final String host;
    private final int port;
    private final ServerFederation federation;
    private final List<ClientHandler> handlers;

    private List<String> communications;
    protected boolean isMaster;

    public CentralServer(String host, int port, ServerFederation federation) {
        this.host = host;
        this.port = port;
        this.federation = federation;
        handlers = new ArrayList<>();
        communications = new ArrayList<>();
        isMaster = false;
    }

    public void setup() {
        try (Selector selector = Selector.open(); ServerSocketChannel serverSocketChannel = ServerSocketChannel.open()) {
            configure(serverSocketChannel, selector, port);

            while (true) {
                selector.select();
                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = selectedKeys.iterator();

                while (iterator.hasNext()) {
                    SelectionKey curr = iterator.next();

                    if (curr.isAcceptable()) {
                        accept(selector, serverSocketChannel);
                    } else if (curr.isReadable()) {
                        read(curr);
                    }

                    iterator.remove();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void communicate(String communication) throws IOException {
        if (communication.equals("PULL")) {
            List<String> latestCommunications = getFederation().getMasterServer().getCommunicationHistory();
            setCommunications(new ArrayList<>(latestCommunications));

            System.out.println("> Server on port " + port + " synchronized.");
        } else {
            getFederation().getMasterServer().receive(communication, null);
        }
    }

    public void sendCommunication(String communication, ClientHandler sender) throws IOException {
        if(isMaster) {
            ((MasterServer) this).apply(communication, sender);
        } else {
            getFederation().getMasterServer().receive(communication, sender);
        }
    }

    public synchronized void notifyAllClients(ClientHandler sender) {
        for (ClientHandler handler : handlers) {
            if(handler != sender) {
                handler.sendUpdate("NOTIFY");
            }
        }
    }

    public synchronized void broadcast(String command) {
        for (ClientHandler handler : handlers) {
            handler.sendUpdate(command);
        }
    }

    private void configure(ServerSocketChannel serverSocketChannel, Selector selector, int port) throws IOException {
        serverSocketChannel.bind(new InetSocketAddress(port));
        serverSocketChannel.configureBlocking(false);
        serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

        System.out.println((isMaster ? "> Master" : "> Peer") + " is listening on port " + port);
    }

    private void accept(Selector selector, ServerSocketChannel serverSocketChannel) throws IOException {
        if(!isMaster) {
            SocketChannel socketChannel = serverSocketChannel.accept();
            socketChannel.configureBlocking(false);

            ClientHandler clientHandler = new ClientHandler(MasterServer.getClientCount(), socketChannel, this);
            socketChannel.register(selector, SelectionKey.OP_READ, clientHandler);
        }
    }

    private void read(SelectionKey curr) throws IOException {
        ClientHandler handler = (ClientHandler) curr.attachment();
        handler.handle();
    }

    public CollabFile getCollabFile() {
        return federation.getMasterServer().getCollabFile();
    }

    public void addCommunication(String communication) {
        communications.add(communication);
    }

    public synchronized void addHandler(ClientHandler handler) {
        handlers.add(handler);
    }

    public synchronized void removeHandler(ClientHandler handler) {
        handlers.remove(handler);
    }

    public void setCommunications(List<String> communications) {
        this.communications = communications;
    }

    public int getPort() {
        return port;
    }

    public ServerFederation getFederation() {
        return federation;
    }

    public List<String> getCommunications() {
        return communications;
    }

    public boolean isMaster() {
        return isMaster;
    }

    public String getHost() {
        return host;
    }

}