package editor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class MasterServer extends CentralServer {

    private static AtomicInteger clientCount;
    private final CollabFile collabFile;
    private final List<String> communicationHistory;

    public MasterServer(String host, int port, ServerFederation federation, boolean testing) throws IOException {
        super(host, port, federation);
        clientCount = new AtomicInteger(1);
        collabFile = new CollabFile("src/main/resources/file.txt");
        communicationHistory = new ArrayList<>();
        isMaster = true;
        if(testing) {
            test();
        }
    }

    public synchronized void communicate(String communication) throws IOException {
        communicationHistory.add(communication);
        apply(communication, null);

        for (CentralServer server : getFederation().getServers().values()) {
            if(server != this) {
                server.addCommunication(communication);
                server.broadcast("Master > " + communication);
            }
        }
    }

    public synchronized void receive(String communication, ClientHandler sender) throws IOException {
        apply(communication, sender);
    }

    public synchronized void apply(String communication, ClientHandler sender) throws IOException {
        String[] args = communication.split(" ");
        StringBuilder sb = new StringBuilder();

        switch (args[0]) {

            case "ADDL":
                for (int i = 2; i < args.length; i++) sb.append(args[i]).append(" ");
                collabFile.addLine(Integer.parseInt(args[1]), sb.toString().trim());
                break;

            case "RMVL":
                collabFile.removeLine(Integer.parseInt(args[1]));
                break;

            case "MDFL":
                for (int i = 2; i < args.length; i++) sb.append(args[i]).append(" ");
                collabFile.setLine(Integer.parseInt(args[1]), sb.toString().trim());
                break;

            case "ERRL":
                collabFile.error(Integer.parseInt(args[1]));
                break;

            case "PUSH":
                collabFile.incrementVersion();
                communicationHistory.clear();
                notifyClients(sender);
                break;

            default:
                System.out.println("Master > Unknown command received: " + communication);
                break;

        }
    }

    public List<String> getCommunicationHistory() {
        return communicationHistory;
    }

    public CollabFile getCollabFile() {
        return collabFile;
    }

    public static int getClientCount() {
        return clientCount.get();
    }

    public static void incrementClientCount() {
        clientCount.incrementAndGet();
    }

    public static void decrementClientCount() {
        clientCount.decrementAndGet();
    }

    private void notifyClients(ClientHandler sender) {
        for (CentralServer server : getFederation().getServers().values()) {
            server.notifyAllClients(sender);
        }
        collabFile.notifyAllClients();
    }

    private void test() {
        new Thread(() -> {
            long start = System.currentTimeMillis();
            long duration = 3 * 60 * 1000;
            while (System.currentTimeMillis() - start < duration) {
                try {
                    Thread.sleep(15000);
                    System.out.println("Master server paused for 5 seconds...");
                    synchronized (this) {
                        Thread.sleep(5000);
                    }
                    System.out.println("Master server resumed.");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            System.out.println("Master server stopped.");
        }).start();
    }

}