package editor;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClientHandler implements Runnable {

    private final int id;
    private final SocketChannel socketChannel;
    private final CentralServer server;
    private final ByteBuffer buffer;
    private boolean handshaked;

    public ClientHandler(int id, SocketChannel socketChannel, CentralServer server) throws IOException {
        this.id = id;
        this.socketChannel = socketChannel;
        this.server = server;
        buffer = ByteBuffer.allocate(1024);
        handshaked = false;
    }

    @Override
    public void run() {
        try {
            sendCommunications();
        } catch (IOException e) {
            closeConnection();
        }
    }

    public void handle() {
        try {
            buffer.clear();
            int bytesRead = socketChannel.read(buffer);

            if (bytesRead == -1) {
                closeConnection();
                return;
            }

            buffer.flip();

            if (bytesRead > 0) {
                receive(bytesRead);
            }

        } catch (IOException e) {
            closeConnection();
        }
    }

    public void sendUpdate(String command) {
        try {
            ByteBuffer buffer = ByteBuffer.wrap((command + "\n").getBytes());
            while (buffer.hasRemaining()) {
                socketChannel.write(buffer);
            }
        } catch (IOException e) {
            closeConnection();
        }
    }

    private void receive(int bytesRead) throws IOException {
        String receivedData = new String(buffer.array(), 0, bytesRead).trim();
        if (receivedData.isEmpty()) return;

        if (!handshaked) {
            if (receivedData.equals("CLIENT")) {
                System.out.println("> Client #" + id + " connected to server with port: " + server.getPort() + ".");

                handshaked = true;
                server.addHandler(this);

                sendEntireFileContent();
                socketChannel.write(ByteBuffer.wrap("> File transmission completed\n".getBytes()));

                MasterServer.incrementClientCount();
                socketChannel.write(ByteBuffer.wrap(("> Client #" + id + " connected.\n").getBytes()));
            } else {
                System.out.println("> Invalid handshake from Client #" + id + ": [" + receivedData + "]");
                closeConnection();
            }
            return;
        }

        apply(receivedData);
    }

    private String[] extractCommand(String cmd) {
        return cmd.split(" ");
    }

    private void closeConnection() {
        try {
            socketChannel.close();
            server.removeHandler(this);
            System.out.println("> Client #" + id + " disconnected.");
            MasterServer.decrementClientCount();
        } catch (IOException e) {
            System.out.println("> Error closing connection for Client #" + id);
        }
    }

    private void sendEntireFileContent() throws IOException {
        List<String> lines = List.of(getCollabFile().getLines());
        for (String line : lines) {
            socketChannel.write(ByteBuffer.wrap((line + "\n").getBytes()));
        }
    }

    private void sendCommunications() throws IOException {
        List<String> communications = server.getCommunications();
        for (String communication : communications) {
            socketChannel.write(ByteBuffer.wrap((communication + "\n").getBytes()));
        }
    }

    private void apply(String receivedData) throws IOException {
        List<String> communications = new ArrayList<>(Arrays.asList(receivedData.split("\n")));

        for (String communication : communications) {
            if(communication.isEmpty()) continue;

            String[] args = extractCommand(communication);

            switch (args[0]) {

                case "ADDL", "MDFL", "RMVL", "ERRL":
                    server.sendCommunication(communication, this);
                    break;

                case "PUSH":
                    server.sendCommunication(communication, this);
                    server.notifyAllClients(this);
                    break;

                case "PULL":
                    server.communicate("PULL");
                    sendEntireFileContent();
                    sendCommunications();
                    socketChannel.write(ByteBuffer.wrap("> PULL completed\n".getBytes()));
                    break;

                case "GETD":
                    socketChannel.write(ByteBuffer.wrap(("> Current version: " + getCollabFile().getVersion() + "\n").getBytes()));
                    break;

                default:
                    socketChannel.write(ByteBuffer.wrap("> Unknown command\n".getBytes()));
                    System.out.println("> Client #" + id + " sent invalid: " + communication);
                    closeConnection();
            }

            System.out.println("> Client #" + id + " updated the file to version " + getCollabFile().getVersion() + ".");
            server.broadcast(communication);
        }
    }

    public CollabFile getCollabFile() {
        return server.getCollabFile();
    }

}