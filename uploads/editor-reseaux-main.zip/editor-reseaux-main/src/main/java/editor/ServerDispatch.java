package editor;

import java.io.*;
import java.net.*;
import java.util.*;

public class ServerDispatch {

    private final int port;
    private final String host;
    private final ServerFederation federation;

    public ServerDispatch(String host, int port, ServerFederation federation) {
        this.host = host;
        this.port = port;
        this.federation = federation;
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("> ServerDispatch listening on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("> New client connected to ServerDispatch.");
                handle(clientSocket);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handle(Socket clientSocket) {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))) {
            int selectedPort = selectBestServerPort();

            while(federation.getMasterServer().getPort() == selectedPort) {
                selectedPort = selectBestServerPort();
            }

            writer.write(host + ":" + selectedPort);
            writer.newLine();
            writer.flush();

            System.out.println("> Sent client to " + host + ":" + selectedPort);
        } catch (IOException e) {
            e.printStackTrace();

        } finally {

            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private int selectBestServerPort() {
        List<Integer> ports = federation.getPorts();
        Random random = new Random();
        return ports.get(random.nextInt(ports.size()));
    }

}