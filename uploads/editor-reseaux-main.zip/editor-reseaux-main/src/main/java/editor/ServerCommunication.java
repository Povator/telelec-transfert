package editor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.List;

public class ServerCommunication {

    private final CentralServer server;
    private final List<SocketChannel> serverConnections;

    public ServerCommunication(CentralServer server) {
        this.server = server;
        serverConnections = new ArrayList<>();
    }

    public void connect(List<InetSocketAddress> otherServers) {
        for (InetSocketAddress curr : otherServers) {
            try {
                SocketChannel sc = SocketChannel.open();
                sc.configureBlocking(false);
                sc.connect(curr);

                while (!sc.finishConnect()) {
                    Thread.sleep(200);
                }

                serverConnections.add(sc);
                System.out.println("> Connected to server at " + curr);

                new Thread(() -> handle(sc)).start();
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void handle(SocketChannel channel) {
        try {
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            StringBuilder sb = new StringBuilder();

            while (true) {
                int bytesRead = channel.read(buffer);

                if (bytesRead == -1) {
                    System.out.println("> Connection closed by server.");
                    break;
                }

                if (bytesRead == 0) {
                    Thread.sleep(50);
                    continue;
                }

                buffer.flip();
                String str = new String(buffer.array(), 0, bytesRead);
                sb.append(str);
                buffer.clear();

                String[] split = sb.toString().split("\n");

                for (int i = 0; i < split.length - 1; i++) {
                    String msg = split[i].trim();

                    if (!msg.isEmpty()) {
                        System.out.println("> Received from server " + server.getPort() + ":" + server.getPort() + " > " + msg);
                        server.broadcast(msg);
                    }
                }

                sb = new StringBuilder(split[split.length - 1]);
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

}