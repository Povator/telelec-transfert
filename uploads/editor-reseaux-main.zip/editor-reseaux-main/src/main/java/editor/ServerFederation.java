package editor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServerFederation {

    public static void main(String[] args) throws IOException {
        ServerFederation federation = new ServerFederation("localhost");
        federation.loadPorts("src/main/resources/ports.txt");

        federation.setup();
        federation.dispatch("localhost", 1237);
    }

    private final Map<Integer, ServerCommunication> communications;
    private final Map<Integer, CentralServer> servers;
    private final String host;

    private List<Integer> ports;
    private MasterServer masterServer;

    public ServerFederation(String host) {
        this.host = host;
        communications = new HashMap<>();
        servers = new HashMap<>();
        ports = new ArrayList<>();
    }

    public void setup() throws IOException {

        for(int i = 0; i < ports.size(); i++) {
            int port = ports.get(i);
            CentralServer server;

            if(i == 0) {
                masterServer = new MasterServer(host, port, this, false);
                server = masterServer;
            } else {
                server = new CentralServer(host, port, this);
            }

            servers.put(port, server);

            ServerCommunication communication = new ServerCommunication(server);
            communications.put(port, communication);

            new Thread(server::setup).start();
        }

        for(int port : ports) {
            List<InetSocketAddress> otherAddresses = new ArrayList<>();

            for(int otherPort : ports) {
                if(otherPort != port) {
                    otherAddresses.add(new InetSocketAddress(host, otherPort));
                }
            }

            communications.get(port).connect(otherAddresses);
        }

        System.out.println("> Federation setup complete.");
    }

    private void loadPorts(String path) throws IOException {
        List<Integer> ports = new ArrayList<>();
        List<String> lines = Files.readAllLines(Path.of(path));

        for(String line : lines) {
            line = line.trim();
            if(line.isEmpty()) continue;

            String[] args = line.split("=");

            if(args.length != 2) continue;

            String type = args[0].trim();
            String[] address = args[1].trim().split(" ");

            if(address.length != 2) continue;

            int port = Integer.parseInt(address[1].trim());

            if(type.equals("master")) {
                ports.add(0, port);
            } else {
                ports.add(port);
            }
        }

        this.ports = ports;
    }

    private void dispatch(String host, int port) {
        ServerDispatch dispatchServer = new ServerDispatch(host, port, this);

        new Thread(dispatchServer::start).start();
    }

    public List<Integer> getPorts() {
        return ports;
    }

    public Map<Integer, CentralServer> getServers() {
        return servers;
    }

    public MasterServer getMasterServer() {
        return masterServer;
    }

}