package editor;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class CollabFile {

    private final String path;
    private int size;
    private double version;
    private String[] lines;
    private boolean notified;

    public CollabFile(String path) throws IOException {
        this.path = path;
        this.version = 1.0;
        notified = true;
        load();
    }

    private void load() throws IOException {
        List<String> content = Files.readAllLines(Paths.get(path));
        lines = new String[content.size()];

        for (int i = 0; i < content.size(); i++) {
            lines[i] = content.get(i);
        }

        this.size = lines.length;
    }

    public void update() throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(path), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {

            for(int i = 0; i < size; i++) {
                writer.write(lines[i] == null ? "" : lines[i]);
                writer.newLine();
            }

        }
    }

    public void addLine(int index, String text) throws IOException {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Invalid index to add line: " + index);
        }

        String[] newLines = new String[size + 1];
        System.arraycopy(lines, 0, newLines, 0, index);

        newLines[index] = text;
        System.arraycopy(lines, index, newLines, index + 1, size - index);

        lines = newLines;
        size++;
        update();
    }

    public void setLine(int line, String text) throws IOException {
        if (line < 0 || line >= size) {
            throw new IndexOutOfBoundsException("Invalid index to set line: " + line);
        }

        lines[line] = text;
        update();
    }

    public void removeLine(int index) throws IOException {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid index to remove line: " + index);
        }

        String[] newLines = new String[size - 1];

        System.arraycopy(lines, 0, newLines, 0, index);
        System.arraycopy(lines, index + 1, newLines, index, size - index - 1);


        lines = newLines;
        size--;
        update();
    }

    public String getLine(int line) {
        if (line < 0 || line >= size) {
            throw new IndexOutOfBoundsException("Invalid index to get line: " + line);
        }

        return lines[line];
    }

    public void setContent(String content) throws IOException {
        List<String> updated = new ArrayList<>(Arrays.asList(content.split("\n")));
        lines = updated.toArray(new String[0]);

        size = lines.length;
        update();
    }

    public void clear() throws IOException {
        lines = new String[0];
        size = 0;

        update();
    }

    public void incrementVersion() {
        version++;
        notified = false;
    }

    public void error(int index) {
        System.out.println("> Error at line " + index + ".");
    }

    public void version() {
        System.out.println("> Current version: " + version);
    }

    public synchronized void notifyAllClients() {
        notified = true;
    }

    public String getFileContent() {
        return String.join("\n", lines);
    }

    public String getPath() {
        return path;
    }

    public String[] getLines() {
        return lines;
    }

    public int getSize() {
        return size;
    }

    public double getVersion() {
        return version;
    }

    public boolean haveBeenNotified() {
        return notified;
    }

}