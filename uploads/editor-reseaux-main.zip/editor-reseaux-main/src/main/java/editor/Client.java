package editor;

import editor.git.ClientController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Client extends Thread {

    private final String host;
    private final int port;
    private final Socket socket;

    private ClientController clientController;
    private List<String> collabFileData;
    private List<String> communications;

    private boolean canPush;
    private boolean canPull;

    public Client(String host, int port) throws IOException {
        this.host = host;
        this.port = port;
        socket = new Socket(host, port);
        collabFileData = new ArrayList<>();
        communications = new ArrayList<>();
        canPush = true;
        canPull = true;
    }

    public void run() {
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream())); PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);) {
            writer.println("CLIENT");

            boolean receiving = true;
            collabFileData.clear();
            String response;

            while ((response = bufferedReader.readLine()) != null) {
                if (response.startsWith("> Client #")) {
                    continue;
                }

                if (receiving) {
                    if (response.startsWith("> File transmission completed")) {
                        receiving = false;
                        canPush = true;
                        canPull = false;
                    } else {
                        collabFileData.add(response);
                    }
                } else {
                    System.out.println("> " + response);
                    if(response.equals("NOTIFY")) {
                        clientController.disableEditing();
                        canPush = false;
                        canPull = true;
                    }
                    apply(response);
                }

            }
        } catch (IOException e) {
            System.out.println("Error reading from server: " + e.getMessage());
        }
    }

    private void apply(String cmd) {
        String[] args = cmd.split(" ");
        StringBuilder sb = new StringBuilder();
        try {

            switch (args[0]) {

                case "ADDL":
                    for (int i = 2; i < args.length; i++) {
                        sb.append(args[i]).append(" ");
                    }
                    collabFileData.add(Integer.parseInt(args[1]), sb.toString().trim());
                    break;

                case "RMVL":
                    collabFileData.remove(Integer.parseInt(args[1]));
                    break;

                case "MDFL":
                    for (int i = 2; i < args.length; i++) {
                        sb.append(args[i]).append(" ");
                    }
                    collabFileData.set(Integer.parseInt(args[1]), sb.toString().trim());
                    break;

            }

        } catch (Exception e) {
            System.out.println("Failed to apply update: " + cmd);
        }
    }

    public void setClientController(ClientController clientController) {
        this.clientController = clientController;
    }

    public void pull() throws IOException, InterruptedException {
        if(canPull) {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
            Thread.sleep(500);
            printWriter.println("PULL");
            canPush = true;
        }
    }

    public void push() throws IOException {
        if(canPush) {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
            for (String communication : communications) {
                System.out.println(communication);
                printWriter.println(communication);
            }
            printWriter.flush();
            System.out.println("File communications completed.");
            communications.clear();
            canPull = false;
        } else {
            System.out.println("You need to update the file first.");
        }
    }

    public void setCollabFileData(List<String> collabFileData) {
        this.collabFileData = collabFileData;
    }

    public List<String> getCollabFileData() {
        return collabFileData;
    }

    public void addCommunication(String communication) {
        communications.add(communication);
    }

    public void resetCommunications() {
        communications.clear();
    }

    public boolean canPush() {
        return canPush;
    }

    public boolean canPull() {
        return canPull;
    }

    public static Client dispatch(String host, int port) throws IOException {
        Socket socket = new Socket(host, port);
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String address = reader.readLine();
        socket.close();
        String[] split = address.split(":");
        return new Client(split[0], Integer.parseInt(split[1]));
    }

}