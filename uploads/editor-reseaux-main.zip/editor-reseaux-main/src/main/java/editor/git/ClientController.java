package editor.git;

import editor.Client;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientController {

    private Client client;

    @FXML
    private ListView<String> listView;

    @FXML
    private TextField textField;

    @FXML
    private MenuItem deleteLineMenuItem;

    @FXML
    public void initialize() throws IOException {
        disableEditing();
        try {
            client = Client.dispatch("localhost", 1237);
            client.setClientController(this);
            client.start();
            handlePull();
        } catch (IOException e) {
            e.printStackTrace();
        }
        listView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            deleteLineMenuItem.setDisable(newValue == null);
            if (newValue != null) {
                textField.setText(newValue);
            }
        });
    }

    @FXML
    private void handleAddLine() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex == -1) {
            listView.getItems().add("(New Line)");
            client.addCommunication("ADDL " + (listView.getItems().size() - 1) + " (New Line)");
        } else {
            listView.getItems().add(selectedIndex + 1, "(New Line)");
            client.addCommunication("ADDL " + (selectedIndex + 1) + " (New Line)");
        }
    }

    @FXML
    private void handleDeleteLine() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex != -1) {
            listView.getItems().remove(selectedIndex);
            client.addCommunication("RMVL " + (selectedIndex));
        }
    }

    @FXML
    private void handleTextFieldUpdate() {
        int selectedIndex = listView.getSelectionModel().getSelectedIndex();
        if (selectedIndex != -1) {
            listView.getItems().set(selectedIndex, textField.getText());
            client.addCommunication("MDFL " + selectedIndex + " " + textField.getText());
        }
    }

    @FXML
    private void handlePull() throws IOException {
        if(!client.canPull()) return;
        try {
            client.pull();
            List<String> data = client.getCollabFileData();
            client.resetCommunications();
            listView.getItems().clear();
            listView.getItems().addAll(data);
            enableEditing();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handlePush() {
        List<String> lines = new ArrayList<>(listView.getItems());
        client.setCollabFileData(lines);
        try {
            if (client.canPush()) {
                client.addCommunication("PUSH");
                client.push();
            } else {
                alert("You must pull the latest version before pushing changes.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void alert(String str) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.setContentText(str);
            alert.showAndWait();
        });
    }

    public void disableEditing() {
        listView.setDisable(true);
        textField.setDisable(true);
        deleteLineMenuItem.setDisable(true);
    }

    public void enableEditing() {
        listView.setDisable(false);
        textField.setDisable(false);
        deleteLineMenuItem.setDisable(false);
    }

}