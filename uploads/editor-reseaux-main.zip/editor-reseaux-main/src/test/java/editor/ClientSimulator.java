package editor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClientSimulator {

    public static void main(String[] args) {
        String host = "localhost";
        int[] ports = {1235, 1236};

        List<Client> clients = new ArrayList<>();

        try {
            for (int i = 0; i < 10; i++) {
                int port = ports[i % ports.length];
                Client client = new Client(host, port);
                clients.add(client);
                client.start();
                System.out.println("Client #" + (i + 1) + " connected to server on port " + port);
                Thread.sleep(200);
            }
            Thread.sleep(2000);
            for(int i = 0; i < clients.size(); i++) {
                Client client = clients.get(i);
                int clientId = i + 1;
                client.addCommunication("ADDL 0");
                client.addCommunication("MDFL 0 Edited by Client " + clientId);
                client.push();
                Thread.sleep(200);
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("Failed to create client: " + e.getMessage());
        }
    }

}